# Research agenda — known gaps and next investigations

Gap: Administrative Constraints on System Simplification
Question: What specific statutory, financial, or technological constraints prevent local election officials from simplifying ballot design or distributing neutral local candidate data?
Method: Semi-structured interview with a local County Clerk or Registrar of Voters.

Gap: Real-Time Points of Voter Abandonment
Question: At what specific step or concept during voter outreach do citizens express confusion or the desire to give up on participating?
Method: Informational interviews with Get-Out-The-Vote (GOTV) field organizers and community canvassers.

Gap: Voter Cognitive Bandwidth Limits
Question: At what exact point on a sample ballot or voter guide does procedural complexity exceed a voter's available mental bandwidth?
Method: Visual heatmap and think-aloud usability survey with low-propensity voters using real sample ballots.

Gap: High-Complexity Reform Without Turnout Drop
Question: Which municipalities implemented complex voting reforms without a drop in turnout, and what specific public education interventions prevented confusion?
Method: Secondary comparative case study analysis using Perplexity deep research.

Gap: Disinformation Playbook in Local Information Deserts
Question: How do bad actors specifically exploit local candidate information gaps to deploy targeted disinformation and manipulate voters?
Method: Analytical synthesis prompt using Claude on documented hyper-local disinformation tactics.