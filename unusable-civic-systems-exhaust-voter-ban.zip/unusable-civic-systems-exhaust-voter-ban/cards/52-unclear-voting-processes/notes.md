# Unclear voting processes

*Evidence · Evidence*

Challenge of educating voters quickly and efficiently on voting and electoral issues

## Built from

  - Signal "Logistical & Educational Barriers to Voting": Voting is burdened by physical hurdles (childcare, time off work) and a lack of plain-language education on how local elections directly impact citizens' daily lives.
  - Signal "Unexplained Ballot Roles": Even where ranked-choice mechanics were well taught, voters lack a plain-language breakdown of what each office on the ballot actually does, leaving first-time voters guessing at the roles they're electing.
