# Untitled

*Evidence · Evidence*

## Built from

  - Signal "AI Bot Interference in Constituent Engagement": Artificial intelligence is being used to flood communication channels, rendering actual, organic constituent engagement ineffective.
  - Signal "Missing Dialogue Across Difference": People who hold differing views about a topic rarely talk with each other; new civic-engagement software is being tried, with only some success.
