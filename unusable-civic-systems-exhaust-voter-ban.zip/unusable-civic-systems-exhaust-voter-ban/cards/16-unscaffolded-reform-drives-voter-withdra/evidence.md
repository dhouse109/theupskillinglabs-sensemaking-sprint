  • Problem: Procedural Friction Triggers Civic Withdrawal — Voters facing convoluted voting mechanics, such as ranked-choice rules, and a polluted information environment opt out of participating rather than navigate a system they cannot decode.
    - Signal "voter turnout": people who are impacted by result don't show up to vote.
- no trust in system
- confusion over requirements & process
- misinformation
    - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
  • History: Implementation Outpaces Educational Scaffolding — When administrators deploy new ranked-choice voting structures without providing sufficient public education or unbiased candidate data, voters are left confused by the mechanics and unable to adapt their voting behavior.
    - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
    - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.