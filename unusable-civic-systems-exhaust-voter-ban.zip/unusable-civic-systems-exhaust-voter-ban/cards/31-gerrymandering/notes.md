# Gerrymandering

*Evidence · Evidence*

## Built from

  - Signal "Structural Election Imbalances": The current electoral system features gerrymandering, dominant two-party privileges, and districts so large that politicians effectively choose their voters.
  - Signal "Low-Information Voting & Gerrymandering": Many voters don't research candidates before an election, while nationwide gerrymandering and proposed federal voting restrictions make the underlying playing field less fair.
