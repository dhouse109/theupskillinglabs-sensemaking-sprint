  • Problem: Local Information Deserts Invite Manipulation — The systemic absence of actionable local candidate data creates an information vacuum, forcing voters to rely on superficial cues like yard signs while leaving them highly vulnerable to targeted disinformation.
    - Signal "Local Candidate Information Gaps": Voters lack easily accessible, actionable information about local county-level candidates, often relying heavily on name recognition from campaign signs.
    - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
  • History: Disinformation Exploits Baseline Civic Confusion — Political entities use internet-era disinformation to weaponize voters' lack of procedural literacy, leading impacted populations to either withdraw completely or succumb to manipulated instincts.
    - Signal "voter turnout": people who are impacted by result don't show up to vote.
- no trust in system
- confusion over requirements & process
- misinformation
    - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.