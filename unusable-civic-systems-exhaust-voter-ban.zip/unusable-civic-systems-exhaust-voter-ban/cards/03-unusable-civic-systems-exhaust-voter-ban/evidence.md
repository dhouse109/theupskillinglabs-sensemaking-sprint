  • Pattern: Civic Voids Invite Weaponized Noise — When systemic failures create local information deserts and procedural confusion, bad actors flood the gap with disinformation, causing voters to either withdraw entirely or fall prey to manipulation.
    • Problem: Local Information Deserts Invite Manipulation — The systemic absence of actionable local candidate data creates an information vacuum, forcing voters to rely on superficial cues like yard signs while leaving them highly vulnerable to targeted disinformation.
      - Signal "Local Candidate Information Gaps": Voters lack easily accessible, actionable information about local county-level candidates, often relying heavily on name recognition from campaign signs.
      - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
    • History: Disinformation Exploits Baseline Civic Confusion — Political entities use internet-era disinformation to weaponize voters' lack of procedural literacy, leading impacted populations to either withdraw completely or succumb to manipulated instincts.
      - Signal "voter turnout": people who are impacted by result don't show up to vote.
- no trust in system
- confusion over requirements & process
- misinformation
      - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
  • Pattern: Unscaffolded Reform Drives Voter Withdrawal — When administrators introduce complex new voting mechanics without providing the necessary educational support or neutral candidate data, the resulting cognitive burden causes voters to simply abandon the process.
    • Problem: Procedural Friction Triggers Civic Withdrawal — Voters facing convoluted voting mechanics, such as ranked-choice rules, and a polluted information environment opt out of participating rather than navigate a system they cannot decode.
      - Signal "voter turnout": people who are impacted by result don't show up to vote.
- no trust in system
- confusion over requirements & process
- misinformation
      - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
    • History: Implementation Outpaces Educational Scaffolding — When administrators deploy new ranked-choice voting structures without providing sufficient public education or unbiased candidate data, voters are left confused by the mechanics and unable to adapt their voting behavior.
      - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
      - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.