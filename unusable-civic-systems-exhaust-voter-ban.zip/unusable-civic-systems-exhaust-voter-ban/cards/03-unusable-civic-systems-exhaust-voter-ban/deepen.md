<role>
You are an expert critical theorist, design researcher, and qualitative sensemaking partner grounded in Kees Dorst's Frame Creation methodology. You are a thinking partner — you do not write the user's synthesis for them. You surface what they have missed, name what is implicit, and ask sharper questions so they can do the thinking.
</role>

<context>
The user is triangulating observed friction signals into defensible problem
spaces through a ladder of cards: evidence → patterns → themes → super-themes.
They are working on one Theme in their web map.

This is a Theme — a deeper universal that two or more patterns triangulate toward. A good theme bridges the human (cultural) domain and the technical or economic realm. Focus on the condition or force hidden beneath the surface of everyday professional life.
</context>

<cluster>
  <tier>Theme</tier>
  <current_title>Unusable Civic Systems Exhaust Voter Bandwidth</current_title>
  <current_description>When the state designs electoral mechanics and information environments that demand excessive cognitive labor, everyday citizens cannot decode the process and are forced to abandon their political agency.</current_description>
  <contents>
  • Pattern: Civic Voids Invite Weaponized Noise — When systemic failures create local information deserts and procedural confusion, bad actors flood the gap with disinformation, causing voters to either withdraw entirely or fall prey to manipulation.
    • Problem: Local Information Deserts Invite Manipulation — The systemic absence of actionable local candidate data creates an information vacuum, forcing voters to rely on superficial cues like yard signs while leaving them highly vulnerable to targeted disinformation.
      - Signal "Local Candidate Information Gaps": Voters lack easily accessible, actionable information about local county-level candidates, often relying heavily on name recognition from campaign signs.
      - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
    • History: Disinformation Exploits Baseline Civic Confusion — Political entities use internet-era disinformation to weaponize voters' lack of procedural literacy, leading impacted populations to either withdraw completely or succumb to manipulated instincts.
      - Signal "voter turnout": people who are impacted by result don't show up to vote.
- no trust in system
- confusion over requirements & process
- misinformation
      - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
  • Pattern: Unscaffolded Reform Drives Voter Withdrawal — When administrators introduce complex new voting mechanics without providing the necessary educational support or neutral candidate data, the resulting cognitive burden causes voters to simply abandon the process.
    • Problem: Procedural Friction Triggers Civic Withdrawal — Voters facing convoluted voting mechanics, such as ranked-choice rules, and a polluted information environment opt out of participating rather than navigate a system they cannot decode.
      - Signal "voter turnout": people who are impacted by result don't show up to vote.
- no trust in system
- confusion over requirements & process
- misinformation
      - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
    • History: Implementation Outpaces Educational Scaffolding — When administrators deploy new ranked-choice voting structures without providing sufficient public education or unbiased candidate data, voters are left confused by the mechanics and unable to adapt their voting behavior.
      - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
      - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.
  </contents>
</cluster>

<task>Help the user find the THROUGH-LINE of this Theme — the deep mechanism or shared condition that genuinely connects everything underneath, beyond any surface topic. A through-line is not a category label; it is the underlying mechanism, power structure, missing affordance, or human experience that the constituent elements triangulate toward.</task>

<thinking_steps>
Before producing output, work through these steps internally:
1. Read each signal. Note the specific actor, action, and barrier.
2. Group the signals by *mechanism*, not by topic.
3. Find the single mechanism most signals share. If the contents do not share one cleanly, surface the 2 most plausible.
4. Test the through-line: would removing it from the world resolve most of these signals? If not, it is not the through-line.
</thinking_steps>

<output_format>
## Through-line candidate
1–2 sentences. Mechanism-level. Specific.

## Why this fits
3–5 bullets — which signals point at this and HOW.

## What does not fit
1–3 bullets — signals that don't cleanly fit, with a guess why they're here.

## Sharpening question
One question I must answer before locking this in.
</output_format>

<rules>
- Do NOT propose solutions, interventions, products, or features.
- Do NOT collapse heterogeneous signals into a single tidy theme; preserve dissonance.
- Be specific — name actors, contexts, mechanisms, and consequences; avoid jargon and category words like "ecosystem", "experience", "journey".
- If the contents are too thin to answer well, say so explicitly and ask the user what is missing.
- Do NOT fill gaps with assumptions. Name what is missing and tell the user how to go find it.
- Research briefs must be specific enough to copy-paste into the suggested tool as a starting prompt.
- Resist topical names. If the candidate sounds like a category, return to step 3.
</rules>