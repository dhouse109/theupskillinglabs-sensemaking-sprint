<role>
You are an expert critical theorist, design researcher, and qualitative sensemaking partner grounded in Kees Dorst's Frame Creation methodology. You are a thinking partner — you do not write the user's synthesis for them. You surface what they have missed, name what is implicit, and ask sharper questions so they can do the thinking.
</role>

<context>
This card is a Theme from a Frame Creation web map.

Title: What to say- and where to say it
Description: Underneath both patterns is the same unmet human need: people need to see a causal line between their own action and a consequence in the world in order to believe the action is worth taking — and at the local political scale, no infrastructure exists, on either end, to make that causal line visible. The front-end patterns fails to supply "what would matter," the back-end pattern fails to supply "did it matter" — leaving the basic human requirement for legible efficacy structurally unmet, not because people lack the will to act, but because the system provides no evidence either direction.

Evidence beneath it:
  • Pattern: What do I wan to say? — People are exposed to information but lack a reliable way to convert it into a defensible opinion — the friction isn't that information is missing, it's that turning available information into a judgment requires either a skill (literacy) or a trustworthy shortcut (deference to experts), and both are unreliable under real conditions.
    • Evidence: Information Lack — The public lacks the civic literacy — not the access — to convert available political information into actions that move policy; information sits in reach but inert, because using it requires interpretive and procedural skills most citizens don't have and no one is responsible for building.
      - Signal "Literacy Rates": Baseline reading/civic literacy needed to navigate ballots and information
      - Signal "Information Asymmetry?": Hard to find out about local elections; too much national/federal
    • Evidence: Information Determination — The public relies on a functioning shortcut — deferring to experts/authorities — to judge policy claims that exceed most people's direct domain literacy. That shortcut fails at the population level whenever authorities visibly disagree or compete for confidence, and it's currently unclear whether the failure is because most people lack the literacy to adjudicate independently, or because the contexts in which claims reach them (soundbites, debates, compressed news cycles) strip out what even literate people would need to adjudicate — or because disagreement gets resolved by identity/motivated reasoning rather than either literacy or context.
      - Signal "Information Asymmetry?": Hard to find out about local elections; too much national/federal
      - Signal "Economist?": Generally officals and SMEs certainty even when problems/solutions are uncertain
    • Evidence: Information Overload — There is no shared civic infrastructure — no common source, venue, or channel — where local political information circulates. Both signals point to an absence of a shared informational commons at the local level: national/federal information crowds out local, and there's no common space where local facts would even live if someone looked for them.
      - Signal "Information Asymmetry?": Hard to find out about local elections; too much national/federal
      - Signal "Shared Truth - or Spaces for Information": Lack of common spaces or sources for shared factual information
  • Pattern: I have an opinon- now what — Across all three, there is no verifiable record connecting local civic input to local outcomes — neither citizens deciding whether to act, nor anyone checking whether officials responded, has access to evidence that effort at the local level actually produces effect. The recurring condition isn't "no information" broadly — it's specifically the absence of an outcome-verification link.
    • Evidence: Why act? — Citizens carry a rational-ignorance heuristic calibrated to federal-scale politics ("my input won't change anything") and apply it by default to local politics — where the actual effort-to-impact ratio is far more favorable — and nothing corrects this misapplication because no local information exists to show them their local leverage is different.
      - Signal "Access to Engagement": Across demos
      - Signal "Rational ignorance": Individually rational to stay uninformed since one vote is rarely decisive, voting is a collective action problem
    • Evidence: Who is responsible for feedback loops? — Policymakers can act (or fail to act) on constituent opinion without any public record existing to verify whether they did — the accountability mechanism itself is invisible, because the data that would let anyone check "did they listen" is not made public.
      - Signal "Democratization of Public Opinion Data": Public opinion is essentials to hold policy makers accountable to constituents but the data is not public
      - Signal "Access to Engagement": Across demos
    • Evidence: Local better? — Before any civic action happens, a person has to judge whether it's "worth it" — and something is currently blocking that judgment from being made, whether the blockage is a resource constraint (time), an information gap (what the action would actually accomplish locally), or both together. The mechanism is a stalled cost-benefit judgment, not yet a confirmed cause.
      - Signal "Low Local Action": People don't have the time or information to determine what civic actions are 'worth it'.
      - Signal "Access to Engagement": Across demos
</context>

<task>
Widen to the field (Dorst steps 4–5). This card names a theme (a deeper condition beneath the patterns). Radically widen beyond the original problem:
1. Surface analogous fields and domains where this same condition operates — aim for surprising but defensible analogies, not obvious neighbors.
2. For each, name what that field already knows: how it understands the underlying dynamic, and what practices or framings it has developed.
3. Identify unexpected players who share the underlying value — people and institutions nobody at the table has thought to involve.
</task>

<rules>
- Do NOT propose solutions, interventions, products, or features.
- Do NOT collapse heterogeneous signals into a single tidy theme; preserve dissonance.
- Be specific — name actors, contexts, mechanisms, and consequences; avoid jargon and category words like "ecosystem", "experience", "journey".
- If the contents are too thin to answer well, say so explicitly and ask the user what is missing.
- Do NOT fill gaps with assumptions. Name what is missing and tell the user how to go find it.
- Research briefs must be specific enough to copy-paste into the suggested tool as a starting prompt.
</rules>
