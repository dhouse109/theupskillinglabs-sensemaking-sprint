# finding localized community engagement opportunities

*Evidence · Evidence*

## Built from

  - Signal "Campus–Neighborhood Disconnection": There is no single, easy channel for a university community and its neighbors to trade information and opportunities — student jobs, local events, programs, and campus resources live in scattered slices.
  - Signal "Finding hyper-local": community engagement is hard
