  • Evidence: Equity of representation — System designers and incumbent gatekeepers operate rules that freeze demographic power balances before ballots are cast. As a result, non-dominant groups waste agency trying to win within a rigged spatial and institutional architecture.
    - Signal "Equality of representation": gerrymandering voters are not equally represented
    - Signal "Women Still Under-Represented": Women remain under-represented in political leadership, even as women run for the highest offices.
  • Evidence: Participation apathy — Voters recognize that traditional turnout mechanisms yield negligible structural change, resulting in deliberate, rational non-participation.
    - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
    - Signal "Participation apathy": voter turnout is low