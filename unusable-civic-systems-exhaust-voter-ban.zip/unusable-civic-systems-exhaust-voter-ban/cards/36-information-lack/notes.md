# Untitled

> **Evidence · Evidence** — a card in a Frame Creation web map.
> Built from 2 signal(s). The work on this page is to *investigate the field*, not to solve.

## What these signals jointly establish
*Two or more signals triangulating on one claim. State the claim they make together.*

## What kind of evidence is this?
*Decide the movement first — are you excavating the known problem (Archaeology & Context: history, counterfactual, problem, boundary, flux) or widening to the players and values of the field (Field mapping: player, value)? Classify it once the situation is mapped, then deepen with the matching prompts.*

---

## Evidence & sources
*Primary (from the situation itself — interviews, field notes, documents) and secondary (literature, data, prior art). Attach files below; list and annotate them here.*

## Where I'm not sure
*Your confidence. What would change your mind? What would falsify this?*

## Whose voice is still missing
*Who hasn't been heard yet — and how would they complicate this?*


Through-line candidate

The public lacks the civic literacy — not the access — to convert available political information into actions that move policy; information sits in reach but inert, because using it requires interpretive and procedural skills most citizens don't have and no one is responsible for building.

Why this fits
"Literacy Rates" is now the load-bearing signal, not a side constraint: baseline reading/civic literacy is the mechanism, not a modifier on it.
"Information Asymmetry?" gets reinterpreted under your framing — the "hard to find" experience is a symptom of not knowing how to search/interpret, not a supply gap. Same underlying deficit, different surface complaint.
Test: flood the zone with more local coverage (fix "access") and the mechanism you're describing predicts nothing changes, because the bottleneck was never supply. That's consistent with your read — and it's exactly what should make you suspicious of "Problem" framing, which assumes fixing supply fixes the outcome.
What does not fit
Nothing contradicts this reading now — but note you've collapsed the dissonance I flagged last time (access vs. capacity) by choosing capacity. That's a legitimate analytical move, just confirm it's not discarding real signal buried in "Information Asymmetry?" (e.g., is there also a genuine local-coverage scarcity problem worth its own Evidence card, separate from literacy?).
Sharpening question

Boundary or Player? You're currently naming this as a fixed trait of "the public" (Boundary: "citizens will never have the civic literacy to..."). But it could also be read as a Player card — the public as a stakeholder defined by their actual practices and currency (how they really do get information — social media, word of mouth, family) versus the practices the system assumes they have. That reframes it from a nonnegotiable deficit into a mismatch between assumed and actual practice, which stays more solvable. Which one are you observing: a hard ceiling on what citizens can do, or a gap between what the system expects of them and how they actually operate?
