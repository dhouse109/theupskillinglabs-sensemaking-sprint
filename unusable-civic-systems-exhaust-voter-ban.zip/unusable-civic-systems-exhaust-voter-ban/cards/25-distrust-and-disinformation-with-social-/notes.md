# Distrust and Disinformation with social media

*Evidence · Evidence*

## Built from

  - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
  - Signal "AI Bot Interference in Constituent Engagement": Artificial intelligence is being used to flood communication channels, rendering actual, organic constituent engagement ineffective.
