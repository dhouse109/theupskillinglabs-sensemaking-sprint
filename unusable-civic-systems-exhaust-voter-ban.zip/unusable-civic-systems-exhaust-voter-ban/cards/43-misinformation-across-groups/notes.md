# Misinformation across groups

*Evidence · Evidence*

## Built from

  - Signal "Media Misinformation": Broad concerns regarding how misleading media and digital influencing are negatively impacting civic engagement.
  - Signal "Truths / Facts": are not shared across groups
