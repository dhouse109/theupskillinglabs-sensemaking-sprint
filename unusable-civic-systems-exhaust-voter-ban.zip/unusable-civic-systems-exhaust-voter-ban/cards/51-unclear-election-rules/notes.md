# Unclear election rules

*Evidence · Evidence*

The impacts of election processes are opaque for citizens.

## Built from

  - Signal "Unexplained Ballot Roles": Even where ranked-choice mechanics were well taught, voters lack a plain-language breakdown of what each office on the ballot actually does, leaving first-time voters guessing at the roles they're electing.
  - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.
  - Signal "Calls for Stricter Ballot ID": A demand that in-person voting require Real ID and that mail-in ballots require verified identification — described by the submitter as widely supported yet repeatedly rejected.
